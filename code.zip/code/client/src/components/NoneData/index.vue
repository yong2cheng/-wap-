<template>
	<div class="none-data-wrapper">
		<img src="../../images/none-data.png" alt="">
		<div>暂无数据</div>
	</div>
</template>
<style lang="less" scoped>
	.none-data-wrapper {
		text-align: center;
		margin: 175px 0;
	}
	
</style>