import login from '../../views/login/index'

let loginArr=[
    {//登陆模块
        path: '/login',
        name: 'login',
        component: login
      }
]
export default loginArr