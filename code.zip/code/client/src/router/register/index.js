import register from '../../views/register/index'

let registerArr=[
    {//登陆模块
        path: '/register',
        name: 'register',
        component: register
      }
]
export default registerArr