<template lang="html">
    <div class="wrap">
        <main>
            <router-view/>
        </main>
    </div>
</template>
<script>
export default {
    name:'userCenterMain',
    components:{
    }
}
</script>
<style lang="css">
</style>
