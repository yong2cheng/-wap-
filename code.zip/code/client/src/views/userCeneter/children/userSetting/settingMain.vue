<template lang="html">
    <div class="wrap">
        <main>
            <router-view/>
        </main>
    </div>
</template>
<script>
export default {
    name:'settingMain',
    components:{
    }
}
</script>
<style lang="css">
</style>