<template lang="html">
  <div class="wrap">
    <main>
      <router-view/>
    </main>
  </div>
</template>
<script>
export default {
  name:'taskCenterMain',
  components:{
  }
}
</script>
<style lang="css">
</style>
