<template lang="html">
  <div class="wrap">
    <main>
      <router-view/>
    </main>
  </div>
</template>
<script>
export default {
  name:'homeCenterMain',
  components:{
  }
}
</script>
<style lang="css">
</style>
