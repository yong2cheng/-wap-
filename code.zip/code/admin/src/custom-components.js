import IconSvg from 'components/Icon-svg'
const install = Vue => {
    Vue.component('Icon', IconSvg)
}
export default install
