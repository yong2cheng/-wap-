<template>
<div class="home-container">
    <h1>这是首页</h1>
</div>
</template>

<script>
    export default {
        name: 'home',
        components: {},
        mounted () {}
    }
</script>


<style lang="less" scoped>
    h1 {
        text-align: center;
        margin-top: 50px;
    }
</style>
